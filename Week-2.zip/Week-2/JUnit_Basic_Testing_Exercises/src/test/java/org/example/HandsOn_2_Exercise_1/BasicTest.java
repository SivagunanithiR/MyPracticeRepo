package org.example.exercise1;

import org.junit.Test;

public class BasicTest {

    @Test
    public void setupTest() {
        System.out.println("JUnit setup is working!");
    }
}
