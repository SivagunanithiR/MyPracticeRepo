package org.example.VerifyingInteractions;

public interface ExternalApi {
    String getData();
}