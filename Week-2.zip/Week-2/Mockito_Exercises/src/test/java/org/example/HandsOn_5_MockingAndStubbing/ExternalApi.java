package org.example.MockingAndStubbing;

public interface ExternalApi {
    String getData();
}